#新增一个集群节点的命令:
$ sudo sed -i '' 's/7000/${指定节点名称}/g' ./new-node.sh
$ sudo ./new-node.sh 
