for((i=1;i<=6;i++)); do /usr/local/redis-cluster/redis-3.2.11/src/redis-server /usr/local/redis-cluster/703$i/redis.conf; done
