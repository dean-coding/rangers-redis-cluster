mkdir -p /usr/local/redis-cluster/7037 && cp ./redis.conf.demo /usr/local/redis-cluster/7037/redis.conf && sed -i '' 's/7030/7037/g' /usr/local/redis-cluster/7037/redis.conf
