for((i=1;i<=6;i++)); do /usr/local/redis-cluster/redis-3.2.11/src/redis-cli -c -h 127.0.0.1 -p 703$i shutdown; done
